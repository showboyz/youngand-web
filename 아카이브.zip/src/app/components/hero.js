import Animation from "./animation"
import Link from "next/link";

export default function Hero(){
    return(
        <section className="body-font text-gray-600">
                <div className="container mx-auto flex flex-col items-center px-5 py-24 md:flex-row">
                    <div className="mb-10 w-5/6 md:mb-0 md:w-1/2 lg:w-full lg:max-w-lg">
                    <img className="rounded object-cover object-center" alt="hero" src="https://github.com/showboyz/showboyz.github.io/blob/main/iMac%20Pro%20Left%20Side%20View%20Mockup.png?raw=true" />
                    </div>
                    <div className="flex flex-col items-center text-center md:w-1/2 md:items-start md:pl-16 md:text-left lg:flex-grow lg:pl-24">
                    <h1 className="title-font mb-4 text-3xl font-medium text-gray-100 sm:text-4xl">Brain Health Playgound
                </h1>
                    <p className="mb-8 leading-relaxed">This digital healthcare solution that uses AI and computer vision to detect early signs of dementia and deliver personalized cognitive training programs. Our system provides an effective approach for dementia detection and prevention, helping patients maintain and enhance their cognitive function.</p>
                    <div className="flex justify-center">
                        <button className="inline-flex items-center rounded-lg bg-gray-100 px-5 py-3 hover:bg-gray-200 focus:outline-none">
                        <img src="https://github.com/showboyz/showboyz.github.io/blob/main/wind.png?raw=true" fill="currentColor" className="h-7 w-6" viewBox="0 0 512 512">
                        </img>
                        <span className="ml-4 flex flex-col items-start leading-none">
                            <span className="mb-1 text-xs text-gray-600">GET IT ON</span>
                            <span className="title-font font-medium">Windows Store</span>
                        </span>
                        </button>
                    </div>
                    </div>
                </div>
        </section>
    );
}
