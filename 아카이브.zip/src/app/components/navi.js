"use client";

import React, { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';

export default function Navi() {
    const [language, setLanguage] = useState('KOR');

    const toggleLanguage = () => {
        setLanguage(language === 'KOR' ? 'ENG' : 'KOR');
    };

    return (
        <header className="absolute inset-x-0 top-0 z-50">
            <nav className="flex items-center justify-between p-6 lg:px-8" aria-label="Global">
                <div className="flex lg:flex-1">
                <a href="#" className="-m-1.5 p-1.5">
                    <span className="sr-only">youngand</span>
                    <img className="h-8 w-auto" src="https://github.com/showboyz/showboyz.github.io/blob/main/logo4.png?raw=true" alt="youngand" />
                </a>
                </div>
                <div className="flex lg:hidden">
                <button
                    type="button"
                    className="-m-2.5 inline-flex items-center justify-center rounded-md p-2.5 text-gray-700"
                >
                    <span className="sr-only">Open main menu</span>
                    <svg
                    className="h-6 w-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth="1.5"
                    stroke="currentColor"
                    aria-hidden="true"
                    >
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                    </svg>
                </button>
                </div>
                <div className="hidden lg:flex lg:gap-x-12 items-center">
                <Link href="/projects">
                    <p className="text-sm font-semibold leading-6 text-gray-100">Product</p>
                </Link>
                <Link href="/#">
                    <p className="text-sm font-semibold leading-6 text-gray-100">About</p>
                </Link>

                {/* Language toggle button */}
                <button onClick={toggleLanguage} className="flex items-center text-sm font-semibold leading-6 text-gray-100">
                    {language === 'KOR' ? (
                    <>
                        <Image
                        src="https://flagcdn.com/w320/kr.png" // 한국 국기 이미지 경로
                        alt="Korean Flag"
                        width={20}
                        height={16}
                        style={{ objectFit: 'cover' }}
                        />
                        <span className="ml-2">KOR</span>
                    </>
                    ) : (
                    <>
                        <Image
                        src="https://flagcdn.com/w320/us.png" // 미국 국기 이미지 경로
                        alt="US Flag"
                        width={20}
                        height={16}
                        style={{ objectFit: 'cover' }}
                        />
                        <span className="ml-2">ENG</span>
                    </>
                    )}
                </button>
                </div>
            </nav>
        </header>
    );
}
