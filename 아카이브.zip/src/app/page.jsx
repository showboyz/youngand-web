import Hero from "./components/hero"
import Navi from "./components/navi"
import Footer from "./components/footer"
import Events from "./components/events"
import Testimonials from "./components/testimonials"
import Main from "./components/main"
import Features from "./components/features"
import Imageslider from "./components/infiniteslider"
import Pricing from "./components/price"
import Contents from "./components/contents"

export default function Home() {
  return (
  <div className='h bg-gradient-to-b from-slate-950 to-stone-800'>   
    {/* HEADER */}
    <Navi/>
    {/* HERO */}
    <Main/>
    <Hero/>
    {/* BODY */}
    {/* 영앤 기술 */}
    {/* 뇌건강놀이터 소개 */}
    <Contents/>
    <Features/>
    <Imageslider/>
    <Pricing/>
    <Testimonials/>
    <Events/>
    {/* FOOTER */}
    <Footer/>
  </div>
  )
}