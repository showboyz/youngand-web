import Link from "next/link";


export default function Projects(){
    return(
        <div>

            <header class="absolute inset-x-0 top-0 z-50">
                <nav class="flex items-center justify-between p-6 lg:px-8" aria-label="Global">
                    <div class="flex lg:flex-1">
                        <a href="#" class="-m-1.5 p-1.5">
                        <span class="sr-only">youngand</span>
                        <img class="h-8 w-auto" src="https://raw.githubusercontent.com/showboyz/showboyz.github.io/main/logo5.png" alt="youngand" />
                        </a>
                    </div>
                    <div class="flex lg:hidden">
                        <button type="button" class="-m-2.5 inline-flex items-center justify-center rounded-md p-2.5 text-gray-700">
                        <span class="sr-only">Open main menu</span>
                        <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                        </svg>
                        </button>
                    </div>
                    <div class="hidden lg:flex lg:gap-x-12">
                        <Link href="/projects">
                            <p href="#" class="text-sm font-semibold leading-6 text-gray-900">Product</p>
                        </Link>
                        <Link href="/#">
                            <p href="#" class="text-sm font-semibold leading-6 text-gray-900">About</p>
                        </Link>
                        {/* <!-- ENG/KOR --> */}
                    </div>
                </nav>
            </header>
            

            <section class="body-font text-gray-600">
                <div class="container mx-auto flex flex-col items-center px-5 py-24 md:flex-row">
                    <div class="mb-10 w-5/6 md:mb-0 md:w-1/2 lg:w-full lg:max-w-lg">
                    <img class="rounded object-cover object-center" alt="hero" src="https://github.com/showboyz/showboyz.github.io/blob/main/iMac%20Pro%20Left%20Side%20View%20Mockup.png?raw=true" />
                    </div>
                    <div class="flex flex-col items-center text-center md:w-1/2 md:items-start md:pl-16 md:text-left lg:flex-grow lg:pl-24">
                    <h1 class="title-font mb-4 text-3xl font-medium text-gray-900 sm:text-4xl">Brain Health Playgound
                </h1>
                    <p class="mb-8 leading-relaxed">This digital healthcare solution that uses AI and computer vision to detect early signs of dementia and deliver personalized cognitive training programs. Our system provides an effective approach for dementia detection and prevention, helping patients maintain and enhance their cognitive function.</p>
                    <div class="flex justify-center">
                        <button class="inline-flex items-center rounded-lg bg-gray-100 px-5 py-3 hover:bg-gray-200 focus:outline-none">
                        <img src="https://github.com/showboyz/showboyz.github.io/blob/main/Microsoft%20Surface%20Hub00.png?raw=true" fill="currentColor" class="h-7 w-6" viewBox="0 0 512 512">
                        </img>
                        <span class="ml-4 flex flex-col items-start leading-none">
                            <span class="mb-1 text-xs text-gray-600">GET IT ON</span>
                            <span class="title-font font-medium">Windows Store</span>
                        </span>
                        </button>
                    </div>
                    </div>
                </div>
            </section>
            <section class="body-font text-gray-600">
                <div class="container mx-auto px-5 py-24">
                    <div class="mb-20 flex w-full flex-col text-center">
                    <h1 class="title-font mb-4 text-2xl font-medium text-gray-900 sm:text-3xl">Key Features</h1>
                    </div>
                    <div class="-m-4 flex flex-wrap text-center">
                    <div class="w-full p-4 sm:w-1/2 md:w-1/4">
                        <div class="rounded-lg border-2 border-gray-200 px-4 py-6 h-full">
                        <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="mb-3 inline-block h-12 w-12 text-indigo-500" viewBox="0 0 24 24">
                            
                <path d="M14.5 4h-5L7 7H4a2 2 0 00-2 2v9a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2h-3l-2.5-3z" />
                <circle cx="12" cy="13" r="3" />
                        </svg>
                        <p class="leading-relaxed">Motion Tracking</p>
                        </div>
                    </div>
                    <div class="w-full p-4 sm:w-1/2 md:w-1/4">
                        <div class="rounded-lg border-2 border-gray-200 px-4 py-6 h-full">
                        <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="mb-3 inline-block h-12 w-12 text-indigo-500" viewBox="0 0 24 24">
                            <path d="M12 4L12 20" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M8 9L8 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M20 10L20 14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M4 10L4 14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M16 7L16 17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <p class="leading-relaxed">Voice Recognition</p>
                        </div>
                    </div>
                    <div class="w-full p-4 sm:w-1/2 md:w-1/4">
                        <div class="rounded-lg border-2 border-gray-200 px-4 py-6 h-full">
                        <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="0" class="mb-3 inline-block h-12 w-12 text-indigo-500" viewBox="0 0 24 24">
                        <path fill="currentColor" d="M19,7c-0.6,0-1-0.4-1-1c0-2.2-1.8-4-4-4c-1.3,0-2.4,0.6-3.2,1.6c-0.4,0.5-1.2,0.5-1.6,0C8.4,2.6,7.3,2,6,2C3.8,2,2,3.8,2,6
                            c0,0.6-0.4,1-1,1S0,6.6,0,6c0-3.3,2.7-6,6-6c1.5,0,2.9,0.6,4,1.5c1.1-1,2.5-1.5,4-1.5c3.3,0,6,2.7,6,6C20,6.6,19.6,7,19,7z"/>
                        <path fill="currentColor" d="M9.3,19.7c-0.1-0.1-3.2-2.8-5.7-6.1c-0.3-0.4-0.3-1.1,0.2-1.4c0.4-0.3,1.1-0.3,1.4,0.2c1.8,2.3,3.8,4.3,4.8,5.3
                            c1-1,3.1-3,4.9-5.3c0.3-0.4,1-0.5,1.4-0.2c0.4,0.3,0.5,1,0.2,1.4c-2.6,3.3-5.6,6-5.8,6.1C10.3,20.1,9.7,20.1,9.3,19.7z"/>
                        <path fill="currentColor" d="M11,14C11,14,11,14,11,14c-0.4,0-0.7-0.2-0.9-0.6L7.9,9l-1,1.6C6.6,10.8,6.3,11,6,11H1c-0.6,0-1-0.4-1-1s0.4-1,1-1h4.5
                            l1.7-2.6C7.4,6.1,7.7,6,8.1,6c0.4,0,0.7,0.2,0.8,0.6l2.2,4.5l1-1.6C12.4,9.2,12.7,9,13,9h6c0.6,0,1,0.4,1,1s-0.4,1-1,1h-5.5
                            l-1.7,2.6C11.6,13.8,11.3,14,11,14z"/>
                        </svg>
                        <p class="leading-relaxed">Health Monitoring</p>
                        </div>
                    </div>
                    <div class="w-full p-4 sm:w-1/2 md:w-1/4">
                        <div class="rounded-lg border-2 border-gray-200 px-4 py-6 h-full">
                        <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="mb-3 inline-block h-12 w-12 text-indigo-500" viewBox="0 0 24 24">
                            <path d="M3 3V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M23 21H3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M7 16L12.25 10.75L15.75 14.25L21 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <p class="leading-relaxed">Data Analysis</p>
                        </div>
                    </div>
                    </div>
                </div>
            </section>
            {/* <!-- 뇌건강놀이터 소개 --> */}
            <section class="body-font text-gray-600">
            <div class="container mx-auto px-5 py-24">
                <div class="mb-20 flex w-full flex-wrap">
                <div class="mb-6 w-full lg:mb-0 lg:w-1/2">
                    <h1 class="title-font mb-2 text-2xl font-medium text-gray-900 sm:text-3xl">Brain Health Playgound</h1>
                    <div class="h-1 w-20 rounded bg-indigo-500"></div>
                </div>
                <p class="w-full leading-relaxed text-gray-500 lg:w-1/2">Brain Health Playground is a digital healthcare solution that uses computer vision to detect early signs of dementia and provides personalized cognitive training programs to help patients maintain and improve their cognitive function. Our AI-powered system offers a comprehensive and effective solution for dementia detection and prevention..</p>
                </div>
                <div class="-m-4 flex flex-wrap">
                <div class="p-4 md:w-1/2 xl:w-1/4">
                    <div class="rounded-lg bg-gray-100 p-6">
                    <img class="mb-6 h-40 w-full rounded object-cover object-center" src="https://dummyimage.com/720x400" alt="content" />
                    <h3 class="title-font text-xs font-medium tracking-widest text-indigo-500">SUBTITLE</h3>
                    <h2 class="title-font mb-4 text-lg font-medium text-gray-900">Chichen Itza</h2>
                    <p class="text-base leading-relaxed">Fingerstache flexitarian street art 8-bit waistcoat. Distillery hexagon disrupt edison bulbche.</p>
                    </div>
                </div>
                <div class="p-4 md:w-1/2 xl:w-1/4">
                    <div class="rounded-lg bg-gray-100 p-6">
                    <img class="mb-6 h-40 w-full rounded object-cover object-center" src="https://dummyimage.com/721x401" alt="content" />
                    <h3 class="title-font text-xs font-medium tracking-widest text-indigo-500">SUBTITLE</h3>
                    <h2 class="title-font mb-4 text-lg font-medium text-gray-900">Colosseum Roma</h2>
                    <p class="text-base leading-relaxed">Fingerstache flexitarian street art 8-bit waistcoat. Distillery hexagon disrupt edison bulbche.</p>
                    </div>
                </div>
                <div class="p-4 md:w-1/2 xl:w-1/4">
                    <div class="rounded-lg bg-gray-100 p-6">
                    <img class="mb-6 h-40 w-full rounded object-cover object-center" src="https://dummyimage.com/722x402" alt="content" />
                    <h3 class="title-font text-xs font-medium tracking-widest text-indigo-500">SUBTITLE</h3>
                    <h2 class="title-font mb-4 text-lg font-medium text-gray-900">Great Pyramid of Giza</h2>
                    <p class="text-base leading-relaxed">Fingerstache flexitarian street art 8-bit waistcoat. Distillery hexagon disrupt edison bulbche.</p>
                    </div>
                </div>
                <div class="p-4 md:w-1/2 xl:w-1/4">
                    <div class="rounded-lg bg-gray-100 p-6">
                    <img class="mb-6 h-40 w-full rounded object-cover object-center" src="https://dummyimage.com/723x403" alt="content" />
                    <h3 class="title-font text-xs font-medium tracking-widest text-indigo-500">SUBTITLE</h3>
                    <h2 class="title-font mb-4 text-lg font-medium text-gray-900">San Francisco</h2>
                    <p class="text-base leading-relaxed">Fingerstache flexitarian street art 8-bit waistcoat. Distillery hexagon disrupt edison bulbche.</p>
                    </div>
                </div>
                </div>
            </div>
            </section>
            {/* <!-- 가격 정책 --> */}
            <section>
            <div class="mx-auto max-w-screen-xl px-4 py-8 lg:px-6 lg:py-16">
                <div class="mx-auto mb-8 max-w-screen-md text-center lg:mb-12">
                <h2 class="mb-4 text-4xl font-extrabold tracking-tight text-gray-900">Pricing</h2>
                <p class="mb-5 font-light text-gray-500 sm:text-xl dark:text-gray-400">Choose the Subscription Plan that Best Fits Your Needs.</p>
                </div>
                <div class="space-y-8 sm:gap-6 lg:grid lg:grid-cols-3 lg:space-y-0 xl:gap-10">
                {/* <!-- Pricing Card --> */}
                <div class="mx-auto flex max-w-lg flex-col rounded-lg border border-gray-100 bg-white p-6 text-center text-gray-900 shadow xl:p-8 dark:border-gray-0 dark:bg-gray-100 dark:text-black">
                    <h3 class="mb-4 text-2xl font-semibold">Basic</h3>
                    <p class="font-light text-gray-500 sm:text-lg dark:text-gray-400">The ideal option for personal use in the comfort of your home.</p>
                    <div class="my-8 flex items-baseline justify-center">
                    <span class="mr-2 text-5xl font-extrabold">$19</span>
                    <span class="text-gray-500 dark:text-gray-400">/month</span>
                    </div>
                    {/* <!-- List --> */}
                    <ul role="list" class="mb-8 space-y-4 text-left">
                    <li class="flex items-center space-x-3">
                        {/* <!-- Icon --> */}
                        <svg class="h-5 w-5 flex-shrink-0 text-green-500 dark:text-indigo-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg>
                        <span>Individual configuration</span>
                    </li>

                    <li class="flex items-center space-x-3">
                        {/* <!-- Icon --> */}
                        <svg class="h-5 w-5 flex-shrink-0 text-green-500 dark:text-indigo-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg>
                        <span>Real-time training monitoring</span>
                    </li>
                    <li class="flex items-center space-x-3">
                        {/* <!-- Icon --> */}
                        <svg class="h-5 w-5 flex-shrink-0 text-green-500 dark:text-indigo-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg>
                        <span>Free updates: <span class="font-semibold">6 months</span></span>
                    </li>
                    </ul>
                </div>
                {/* <!-- Pricing Card --> */}
                <div class="mx-auto flex max-w-lg flex-col rounded-lg border border-gray-100 bg-white p-6 text-center text-gray-900 shadow xl:p-8 dark:border-gray-0 dark:bg-gray-100 dark:text-black">
                    <h3 class="mb-4 text-2xl font-semibold">Premium</h3>
                    <p class="font-light text-gray-500 sm:text-lg dark:text-gray-400">The perfect solution for personal use and remote counseling.</p>
                    <div class="my-8 flex items-baseline justify-center">
                    <span class="mr-2 text-5xl font-extrabold">$39</span>
                    <span class="text-gray-500 dark:text-gray-400">/month</span>
                    </div>
                    {/* <!-- List --> */}
                    <ul role="list" class="mb-8 space-y-4 text-left">
                    <li class="flex items-center space-x-3">
                        {/* <!-- Icon --> */}
                        <svg class="h-5 w-5 flex-shrink-0 text-green-500 dark:text-green-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg>
                        <span>Individual configuration</span>
                    </li>

                    <li class="flex items-center space-x-3">
                        {/* <!-- Icon --> */}
                        <svg class="h-5 w-5 flex-shrink-0 text-green-500 dark:text-green-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg>
                        <span>Real-time training monitoring</span>
                    </li>
                    <li class="flex items-center space-x-3">
                        {/* <!-- Icon --> */}
                        <svg class="h-5 w-5 flex-shrink-0 text-green-500 dark:text-green-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg>
                        <span>Remote counseling</span>
                    </li>
                    <li class="flex items-center space-x-3">
                        {/* <!-- Icon --> */}
                        <svg class="h-5 w-5 flex-shrink-0 text-green-500 dark:text-green-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg>
                        <span>Free updates: <span class="font-semibold">12 months</span></span>
                    </li>
                    </ul>
                </div>
                {/* <!-- Pricing Card --> */}
                <div class="mx-auto flex max-w-lg flex-col rounded-lg border border-gray-100 bg-white p-6 text-center text-gray-900 shadow xl:p-8 dark:border-gray-0 dark:bg-gray-100 dark:text-black">
                    <h3 class="mb-4 text-2xl font-semibold">Enterprise</h3>
                    <p class="font-light text-gray-500 sm:text-lg dark:text-gray-400">Relevant for multiple users, extended & premium support.</p>
                    <div class="my-8 flex items-baseline justify-center">
                    <span class="mr-2 text-5xl font-extrabold">$999</span>
                    <span class="text-gray-500 dark:text-gray-400">/month</span>
                    </div>
                    {/* <!-- List --> */}
                    <ul role="list" class="mb-8 space-y-4 text-left">
                    <li class="flex items-center space-x-3">
                        {/* <!-- Icon --> */}
                        <svg class="h-5 w-5 flex-shrink-0 text-green-500 dark:text-gcurrentColor" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg>
                        <span>Individual configuration</span>
                    </li>

                    <li class="flex items-center space-x-3">
                        {/* <!-- Icon --> */}
                        <svg class="h-5 w-5 flex-shrink-0 text-green-500 dark:text-green-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg>
                        <span>User size: <span class="font-semibold">100+ Users</span></span>
                    </li>
                    <li class="flex items-center space-x-3">
                        {/* <!-- Icon --> */}
                        <svg class="h-5 w-5 flex-shrink-0 text-green-500 dark:text-green-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg>
                        <span>Premium support: <span class="font-semibold">24 months</span></span>
                    </li>
                    <li class="flex items-center space-x-3">
                        {/* <!-- Icon --> */}
                        <svg class="h-5 w-5 flex-shrink-0 text-green-500 dark:text-green-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg>
                        <span>Free updates: <span class="font-semibold">24 months</span></span>
                    </li>
                    </ul>
                </div>
                </div>
            </div>
            </section>

            {/* <!-- 앱 소개 --> */}
            <section class="body-font text-gray-600">
            <div class="container mx-auto flex flex-col items-center px-5 py-24 md:flex-row">
                <div class="mb-6 flex w-full flex-col pr-0 text-center md:mb-0 md:w-auto md:pr-10 md:text-left">
                <h2 class="title-font mb-1 text-xs font-medium tracking-widest text-indigo-500">COMING SOON</h2>
                <h1 class="title-font text-2xl font-medium text-gray-900 md:text-3xl">Mobile Version</h1>
                </div>
                <div class="mx-auto flex flex-shrink-0 items-center space-x-4 md:ml-auto md:mr-0">
                <button class="inline-flex items-center rounded-lg bg-gray-100 px-5 py-3 hover:bg-gray-200 focus:outline-none">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="h-6 w-6" viewBox="0 0 512 512">
                    <path d="M99.617 8.057a50.191 50.191 0 00-38.815-6.713l230.932 230.933 74.846-74.846L99.617 8.057zM32.139 20.116c-6.441 8.563-10.148 19.077-10.148 30.199v411.358c0 11.123 3.708 21.636 10.148 30.199l235.877-235.877L32.139 20.116zM464.261 212.087l-67.266-37.637-81.544 81.544 81.548 81.548 67.273-37.64c16.117-9.03 25.738-25.442 25.738-43.908s-9.621-34.877-25.749-43.907zM291.733 279.711L60.815 510.629c3.786.891 7.639 1.371 11.492 1.371a50.275 50.275 0 0027.31-8.07l266.965-149.372-74.849-74.847z"></path>
                    </svg>
                    <span class="ml-4 flex flex-col items-start leading-none">
                    <span class="mb-1 text-xs text-gray-600">GET IT ON</span>
                    <span class="title-font font-medium">Google Play</span>
                    </span>
                </button>
                <button class="inline-flex items-center rounded-lg bg-gray-100 px-5 py-3 hover:bg-gray-200 focus:outline-none">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="h-6 w-6" viewBox="0 0 305 305">
                    <path d="M40.74 112.12c-25.79 44.74-9.4 112.65 19.12 153.82C74.09 286.52 88.5 305 108.24 305c.37 0 .74 0 1.13-.02 9.27-.37 15.97-3.23 22.45-5.99 7.27-3.1 14.8-6.3 26.6-6.3 11.22 0 18.39 3.1 25.31 6.1 6.83 2.95 13.87 6 24.26 5.81 22.23-.41 35.88-20.35 47.92-37.94a168.18 168.18 0 0021-43l.09-.28a2.5 2.5 0 00-1.33-3.06l-.18-.08c-3.92-1.6-38.26-16.84-38.62-58.36-.34-33.74 25.76-51.6 31-54.84l.24-.15a2.5 2.5 0 00.7-3.51c-18-26.37-45.62-30.34-56.73-30.82a50.04 50.04 0 00-4.95-.24c-13.06 0-25.56 4.93-35.61 8.9-6.94 2.73-12.93 5.09-17.06 5.09-4.64 0-10.67-2.4-17.65-5.16-9.33-3.7-19.9-7.9-31.1-7.9l-.79.01c-26.03.38-50.62 15.27-64.18 38.86z"></path>
                    <path d="M212.1 0c-15.76.64-34.67 10.35-45.97 23.58-9.6 11.13-19 29.68-16.52 48.38a2.5 2.5 0 002.29 2.17c1.06.08 2.15.12 3.23.12 15.41 0 32.04-8.52 43.4-22.25 11.94-14.5 17.99-33.1 16.16-49.77A2.52 2.52 0 00212.1 0z"></path>
                    </svg>
                    <span class="ml-4 flex flex-col items-start leading-none">
                    <span class="mb-1 text-xs text-gray-600">Download on the</span>
                    <span class="title-font font-medium">App Store</span>
                    </span>
                </button>
                </div>
            </div>
            </section>

            {/* <!-- 뉴스 페이지 --> */}



            <footer class="text-gray-600 body-font">
                <div class="container px-5 py-8 mx-auto flex items-center sm:flex-row flex-col">
                    <a class="flex title-font font-medium items-center md:justify-start justify-center text-gray-900">
                    <img src="https://raw.githubusercontent.com/showboyz/showboyz.github.io/main/logo5.png" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" class="w-100 h-12 text-white p-2" viewBox="0 0 24 24">
                    </img>
                    </a>
                    <p class="text-sm text-gray-500 sm:ml-4 sm:pl-4 sm:border-l-2 sm:border-gray-200 sm:py-2 sm:mt-0 mt-4">© 2024 Youngand All Rights Reserved.
                    </p>
                    <span class="inline-flex sm:ml-auto sm:mt-0 mt-4 justify-center sm:justify-start">
                    <a class="text-gray-500">
                        <svg fill="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" class="w-5 h-5" viewBox="0 0 24 24">
                        <path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"></path>
                        </svg>
                    </a>
                    <a class="ml-3 text-gray-500">
                        <svg fill="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" class="w-5 h-5" viewBox="0 0 24 24">
                        <path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z"></path>
                        </svg>
                    </a>
                    <a class="ml-3 text-gray-500">
                        <svg fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" class="w-5 h-5" viewBox="0 0 24 24">
                        <rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect>
                        <path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37zm1.5-4.87h.01"></path>
                        </svg>
                    </a>
                    <a class="ml-3 text-gray-500">
                        <svg fill="currentColor" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0" class="w-5 h-5" viewBox="0 0 24 24">
                        <path stroke="none" d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z"></path>
                        <circle cx="4" cy="4" r="2" stroke="none"></circle>
                        </svg>
                    </a>
                    </span>
                </div>
            </footer>

        </div>


    )
}